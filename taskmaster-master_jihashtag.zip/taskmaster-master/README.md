Il s'agit de réaliser un programme de job control, en Python.
